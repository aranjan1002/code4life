package networks.project;

class Limits {
    public static int MAX_HOPS = 10000;
}