package networks.project;

import java.lang.Exception;

class NetworkProjectException extends Exception {
    public NetworkProjectException() {
	super();
    }

    public NetworkProjectException(String s) {
	super(s);
    }
}