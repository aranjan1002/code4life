class ServerToServer {
    public ServerToServer(String s) {
	
    }
}