package networks.project;

class CmdCode {
    public static int INSERT = 1;
    public static int DELETE = 2;
    public static int FIND = 3;
    public static int KILL = 4;
    public static int TEST = 5;
}
