To compile:
javac -d ./ *.java

To run server:
java networks.project.UDPServer

To run client:
java networks.project.ClientInterface

To change the port number of server change the configuration file 'server.conf'